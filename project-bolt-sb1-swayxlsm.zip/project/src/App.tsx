import { Card } from "@/components/ui/card";
import { Timer } from "@/components/Timer";
import { Controls } from "@/components/Controls";
import { Settings } from "@/components/Settings";
import { usePomodoro } from "@/hooks/usePomodoro";
import { ThemeToggle } from "@/components/ThemeToggle";
import { BreathingExercise } from "@/components/BreathingExercise";
import { Progress } from "@/components/ui/progress";

export default function App() {
  const { 
    timeLeft, 
    isRunning, 
    isBreak,
    totalSessions,
    settings,
    dailyProgress,
    toggleTimer, 
    resetTimer,
    updateSettings 
  } = usePomodoro();

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4 transition-colors duration-500">
      <Card className="w-full max-w-md p-8 backdrop-blur-sm bg-white/80 dark:bg-slate-900/80 shadow-xl rounded-2xl border-0">
        <div className="text-center space-y-8">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold text-teal-700 dark:text-teal-300">
              {isBreak ? '🌿 Mola Zamanı' : '🎯 Çalışma Zamanı'}
            </h1>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Settings settings={settings} onSave={updateSettings} />
            </div>
          </div>
          
          {isBreak ? (
            <BreathingExercise />
          ) : (
            <Timer 
              timeLeft={timeLeft} 
              isBreak={isBreak} 
              totalTime={isBreak ? settings.breakTime : settings.workTime} 
            />
          )}
          
          <Controls 
            isRunning={isRunning}
            onToggle={toggleTimer}
            onReset={resetTimer}
          />

          <div className="space-y-4">
            <div className="flex justify-between items-center text-sm text-teal-600 dark:text-teal-400">
              <p>
                {isBreak 
                  ? 'Dinlen, gözlerini dinlendir 👀' 
                  : 'Odaklan ve üretken ol ✨'}
              </p>
              <p>Tamamlanan: {totalSessions} 🍅</p>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Günlük Hedef</span>
                <span>{totalSessions} / {settings.dailyGoal}</span>
              </div>
              <Progress value={dailyProgress} className="h-2" />
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}