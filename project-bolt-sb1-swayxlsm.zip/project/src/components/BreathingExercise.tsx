import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

export function BreathingExercise() {
  const [phase, setPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [counter, setCounter] = useState(4);

  useEffect(() => {
    const interval = setInterval(() => {
      setCounter(prev => {
        if (prev <= 1) {
          setPhase(current => {
            switch (current) {
              case 'inhale': return 'hold';
              case 'hold': return 'exhale';
              case 'exhale': return 'inhale';
            }
          });
          return phase === 'hold' ? 7 : 4;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [phase]);

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative">
        <div
          className={cn(
            "w-32 h-32 rounded-full border-4 transition-all duration-1000",
            phase === 'inhale' && "scale-125 border-teal-400",
            phase === 'hold' && "scale-110 border-blue-400",
            phase === 'exhale' && "scale-100 border-purple-400"
          )}
        />
        <span className="absolute inset-0 flex items-center justify-center text-2xl">
          {counter}
        </span>
      </div>
      <p className="text-sm text-muted-foreground">
        {phase === 'inhale' && "Nefes Al"}
        {phase === 'hold' && "Tut"}
        {phase === 'exhale' && "Nefes Ver"}
      </p>
    </div>
  );
}