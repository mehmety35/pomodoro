import { Play, Pause, RefreshCw } from 'lucide-react';
import { Button } from "@/components/ui/button";

interface ControlsProps {
  isRunning: boolean;
  onToggle: () => void;
  onReset: () => void;
}

export function Controls({ isRunning, onToggle, onReset }: ControlsProps) {
  return (
    <div className="flex justify-center gap-4">
      <Button
        onClick={onToggle}
        size="lg"
        className="w-32"
        variant={isRunning ? "destructive" : "default"}
      >
        {isRunning ? (
          <><Pause className="mr-2" size={20} /> Durdur</>
        ) : (
          <><Play className="mr-2" size={20} /> Başlat</>
        )}
      </Button>
      <Button
        onClick={onReset}
        size="lg"
        variant="outline"
        className="w-32"
      >
        <RefreshCw className="mr-2" size={20} /> Sıfırla
      </Button>
    </div>
  );
}