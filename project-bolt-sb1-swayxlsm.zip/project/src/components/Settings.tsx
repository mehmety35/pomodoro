import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Settings as SettingsIcon } from 'lucide-react';
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { TimerSettings } from '@/hooks/usePomodoro';

interface SettingsProps {
  settings: TimerSettings;
  onSave: (settings: TimerSettings) => void;
}

export function Settings({ settings, onSave }: SettingsProps) {
  const [workMinutes, setWorkMinutes] = useState(Math.floor(settings.workTime / 60).toString());
  const [breakMinutes, setBreakMinutes] = useState(Math.floor(settings.breakTime / 60).toString());
  const [autoStartBreaks, setAutoStartBreaks] = useState(settings.autoStartBreaks);
  const [autoStartPomodoros, setAutoStartPomodoros] = useState(settings.autoStartPomodoros);
  const [open, setOpen] = useState(false);

  const handleSave = () => {
    const newSettings: TimerSettings = {
      workTime: Math.max(1, Math.min(60, parseInt(workMinutes, 10))) * 60,
      breakTime: Math.max(1, Math.min(30, parseInt(breakMinutes, 10))) * 60,
      autoStartBreaks,
      autoStartPomodoros
    };
    onSave(newSettings);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="text-teal-600 dark:text-teal-400">
          <SettingsIcon className="h-5 w-5" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Zamanlayıcı Ayarları</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">
              Çalışma Süresi (dakika)
            </label>
            <Input
              type="number"
              min="1"
              max="60"
              value={workMinutes}
              onChange={(e) => setWorkMinutes(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">
              Mola Süresi (dakika)
            </label>
            <Input
              type="number"
              min="1"
              max="30"
              value={breakMinutes}
              onChange={(e) => setBreakMinutes(e.target.value)}
            />
          </div>
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">
              Molaları otomatik başlat
            </label>
            <Switch
              checked={autoStartBreaks}
              onCheckedChange={setAutoStartBreaks}
            />
          </div>
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">
              Pomodoro'ları otomatik başlat
            </label>
            <Switch
              checked={autoStartPomodoros}
              onCheckedChange={setAutoStartPomodoros}
            />
          </div>
          <Button onClick={handleSave} className="w-full">
            Kaydet
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}