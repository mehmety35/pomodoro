import { Progress } from "@/components/ui/progress";
import { formatTime, calculateProgress } from "@/utils/timeUtils";

interface TimerProps {
  timeLeft: number;
  isBreak: boolean;
  totalTime: number;
}

export function Timer({ timeLeft, totalTime }: TimerProps) {
  return (
    <div className="relative w-64 h-64 mx-auto">
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-5xl font-bold text-gray-800 dark:text-gray-100">
          {formatTime(timeLeft)}
        </span>
      </div>
      <Progress 
        value={calculateProgress(timeLeft, totalTime)} 
        className="h-2 w-full absolute bottom-0"
      />
    </div>
  );
}