import { useState, useCallback } from 'react';
import { useTimer } from './useTimer';
import { useStats } from './useStats';
import { DEFAULT_SETTINGS, type TimerSettings } from '@/lib/constants';

export function usePomodoro() {
  const [settings, setSettings] = useState<TimerSettings>(DEFAULT_SETTINGS);
  const [isBreak, setIsBreak] = useState(false);
  
  const { totalSessions, incrementSessions } = useStats();
  
  const handleTimerComplete = useCallback(() => {
    if (isBreak) {
      setIsBreak(false);
    } else {
      incrementSessions();
      setIsBreak(true);
    }
  }, [isBreak, incrementSessions]);

  const { 
    timeLeft, 
    isRunning, 
    toggleTimer, 
    resetTimer 
  } = useTimer({
    duration: isBreak ? settings.breakTime : settings.workTime,
    autoStart: isBreak ? settings.autoStartBreaks : settings.autoStartPomodoros,
    onComplete: handleTimerComplete
  });

  const updateSettings = useCallback((newSettings: TimerSettings) => {
    setSettings(newSettings);
    resetTimer();
    setIsBreak(false);
  }, [resetTimer]);

  return {
    timeLeft,
    isRunning,
    isBreak,
    settings,
    totalSessions,
    toggleTimer,
    resetTimer,
    updateSettings,
    dailyProgress: (totalSessions / settings.dailyGoal) * 100
  };
}