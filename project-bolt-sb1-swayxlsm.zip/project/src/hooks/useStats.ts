import { useState } from 'react';
import { getDailyStats, saveDailyStats } from '@/utils/statsUtils';

export function useStats() {
  const [totalSessions, setTotalSessions] = useState(getDailyStats().sessions);

  const incrementSessions = () => {
    const newTotalSessions = totalSessions + 1;
    setTotalSessions(newTotalSessions);
    saveDailyStats({ sessions: newTotalSessions });
  };

  return {
    totalSessions,
    incrementSessions
  };
}