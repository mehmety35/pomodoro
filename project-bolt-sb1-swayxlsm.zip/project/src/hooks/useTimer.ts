import { useState, useEffect, useCallback } from 'react';
import { playSound } from '@/utils/soundUtils';

interface UseTimerProps {
  duration: number;
  autoStart: boolean;
  onComplete: () => void;
}

export function useTimer({ duration, autoStart, onComplete }: UseTimerProps) {
  const [timeLeft, setTimeLeft] = useState(duration);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    setTimeLeft(duration);
  }, [duration]);

  useEffect(() => {
    let interval: number;

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setIsRunning(autoStart);
            playSound();
            onComplete();
            return duration;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isRunning, timeLeft, duration, autoStart, onComplete]);

  const toggleTimer = useCallback(() => {
    setIsRunning(prev => !prev);
  }, []);

  const resetTimer = useCallback(() => {
    setIsRunning(false);
    setTimeLeft(duration);
  }, [duration]);

  return {
    timeLeft,
    isRunning,
    toggleTimer,
    resetTimer
  };
}