export interface TimerSettings {
  workTime: number;
  breakTime: number;
  autoStartBreaks: boolean;
  autoStartPomodoros: boolean;
  dailyGoal: number;
}

export const DEFAULT_SETTINGS: TimerSettings = {
  workTime: 25 * 60,
  breakTime: 5 * 60,
  autoStartBreaks: true,
  autoStartPomodoros: false,
  dailyGoal: 8
};