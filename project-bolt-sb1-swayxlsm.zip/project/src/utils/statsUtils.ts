interface DailyStats {
  sessions: number;
  date: string;
}

const getTodayKey = () => new Date().toISOString().split('T')[0];

export const getDailyStats = (): DailyStats => {
  const stats = localStorage.getItem('pomodoro-stats');
  if (stats) {
    const parsed = JSON.parse(stats);
    if (parsed.date === getTodayKey()) {
      return parsed;
    }
  }
  return { sessions: 0, date: getTodayKey() };
};

export const saveDailyStats = (stats: Partial<DailyStats>) => {
  const current = getDailyStats();
  const updated = {
    ...current,
    ...stats,
    date: getTodayKey()
  };
  localStorage.setItem('pomodoro-stats', JSON.stringify(updated));
};